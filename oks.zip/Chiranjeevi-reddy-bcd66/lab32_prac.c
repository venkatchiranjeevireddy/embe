#include <reg51.h>

void main()
{
    int i;
    char msg[] = "I love india";

    SCON = 0x50;
    TMOD = 0x20;
    TH1 = 0xFD;
    TR1 = 1;

    while(1)
    {
        for(i = 0; msg[i] != '\0'; i++)
        {
            SBUF = msg[i];
            while(TI == 0);
            TI = 0;
        }
    }
}