.\lab61prac.o: lab61prac.c
.\lab61prac.o: C:\Keil\ARM\Inc\Philips\lpc214x.h
