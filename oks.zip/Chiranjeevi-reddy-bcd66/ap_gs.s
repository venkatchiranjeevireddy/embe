        AREA AP_PROG, CODE, READONLY
        ENTRY

        MOV R0, #3      ; first term (a)
        MOV R1, #7      ; common difference (d)
        MOV R2, #10     ; number of terms

AP_LOOP
        ADD R0, R0, R1
        SUBS R2, R2, #1
        BNE AP_LOOP

AP_STOP
        B AP_STOP

        END