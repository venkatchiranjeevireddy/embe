.\bcd0066.o: bcd0066.s
