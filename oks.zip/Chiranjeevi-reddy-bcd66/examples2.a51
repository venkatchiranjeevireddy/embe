ORG 0000H

MOV R7,#05H          ; N = 5 bytes
MOV DPTR,#3000H      ; External memory start
MOV R0,#50H          ; Internal RAM 50H (acts like 3050H lower byte)

LOOP:
    MOVX A,@DPTR     ; Read from 3000H
    MOV R1,A         ; Save temporarily

    MOV A,@R0        ; Read from 50H
    MOVX @DPTR,A     ; Store into 3000H

    MOV A,R1         ; Get original value
    MOV @R0,A        ; Store into 50H

    INC DPTR
    INC R0
    DJNZ R7,LOOP

HERE: SJMP HERE

END