#include <reg51.h>
sbit RS = P3^0;
sbit RW = P3^1;
sbit EN = P3^2;

void delay()
{
int i,j;
for(i=0;i<100;i++)
for(j=0;j<1000;j++);
}

void lcd_cmd(unsigned char cmd)
{
P2 = cmd; // ? send data to P2
RS = 0;
RW = 0;
EN = 1;
delay();
EN = 0;
}

void lcd_data(unsigned char dat)
{
P2 = dat; // ? send data to P2
RS = 1;
RW = 0;
EN = 1;
delay();
EN = 0;
}

void lcd_init()
{
lcd_cmd(0x38); // 8-bit, 2 line
lcd_cmd(0x0C); // display ON
lcd_cmd(0x01); // clear display
lcd_cmd(0x06); // entry mode
}

void lcd_string(char *str)
{
while(*str)
{
lcd_data(*str++);
}
}

void main()
{
lcd_init();
lcd_string("2023 Batch");

while(1);
}