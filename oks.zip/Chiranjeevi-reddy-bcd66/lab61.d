.\lab61.o: lab61.c
.\lab61.o: C:\Keil\ARM\Inc\Philips\lpc214x.h
