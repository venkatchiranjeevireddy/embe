   AREA RESET, CODE, READONLY
        ENTRY

IO0DIR  EQU 0xE0028008
IO0SET  EQU 0xE0028004
IO0CLR  EQU 0xE002800C

IO1DIR  EQU 0xE0028018
IO1SET  EQU 0xE0028014
IO1CLR  EQU 0xE002801C

START

;-------------------------------
; Configure LCD Data Pins
; P1.16 � P1.23
;-------------------------------

        LDR R0, =IO1DIR
        LDR R1, [R0]
        LDR R2, =0x00FF0000
        ORR R1, R1, R2
        STR R1, [R0]

;-------------------------------
; Configure Control Pins
; P0.7 EN
; P0.8 RS
; P0.9 RW
;-------------------------------

        LDR R0, =IO0DIR
        LDR R1, [R0]
        ORR R1, R1, #(1<<7)
        ORR R1, R1, #(1<<8)
        ORR R1, R1, #(1<<9)
        STR R1, [R0]

;-------------------------------
; LCD Initialization
;-------------------------------

        MOV R1, #0x38
        BL LCD_CMD

        MOV R1, #0x0C
        BL LCD_CMD

        MOV R1, #0x06
        BL LCD_CMD

        MOV R1, #0x01
        BL LCD_CMD

;-------------------------------
; Print "My India"
;-------------------------------

        LDR R0, =MSG

LOOP
        LDRB R1, [R0], #1
        CMP R1, #0
        BEQ STOP
        BL LCD_DATA
        B LOOP

STOP
        B STOP


;===============================
; LCD COMMAND
;===============================

LCD_CMD
        MOV R6, LR        ; save return address

        LDR R2, =IO1CLR
        LDR R3, =0x00FF0000
        STR R3, [R2]

        LDR R2, =IO1SET
        MOV R3, R1
        LSL R3, R3, #16
        STR R3, [R2]

        LDR R2, =IO0CLR
        MOV R3, #(1<<8)
        STR R3, [R2]

        MOV R3, #(1<<9)
        STR R3, [R2]

        LDR R2, =IO0SET
        MOV R3, #(1<<7)
        STR R3, [R2]

        BL DELAY

        LDR R2, =IO0CLR
        MOV R3, #(1<<7)
        STR R3, [R2]

        BL DELAY

        MOV LR, R6        ; restore return address
        BX LR


;===============================
; LCD DATA
;===============================

LCD_DATA
        MOV R6, LR        ; save return address

        LDR R2, =IO1CLR
        LDR R3, =0x00FF0000
        STR R3, [R2]

        LDR R2, =IO1SET
        MOV R3, R1
        LSL R3, R3, #16
        STR R3, [R2]

        LDR R2, =IO0SET
        MOV R3, #(1<<8)
        STR R3, [R2]

        LDR R2, =IO0CLR
        MOV R3, #(1<<9)
        STR R3, [R2]

        LDR R2, =IO0SET
        MOV R3, #(1<<7)
        STR R3, [R2]

        BL DELAY

        LDR R2, =IO0CLR
        MOV R3, #(1<<7)
        STR R3, [R2]

        BL DELAY

        MOV LR, R6        ; restore return address
        BX LR


;===============================
; DELAY
;===============================

DELAY
        LDR R4, =50000
DELAY_LOOP
        SUBS R4, R4, #1
        BNE DELAY_LOOP
        BX LR


;===============================
; STRING
;===============================

MSG
        DCB "My India",0

        END