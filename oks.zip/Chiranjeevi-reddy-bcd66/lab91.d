.\lab91.o: lab91.c
.\lab91.o: C:\Keil\ARM\Inc\Philips\LPC214x.h
