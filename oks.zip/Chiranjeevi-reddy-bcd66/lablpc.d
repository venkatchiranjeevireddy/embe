.\lablpc.o: lablpc.c
.\lablpc.o: C:\Keil\ARM\Inc\Philips\lpc214x.h
