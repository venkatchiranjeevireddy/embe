.\lpcc.o: lpcc.c
.\lpcc.o: C:\Keil\ARM\Inc\Philips\lpc214x.h
