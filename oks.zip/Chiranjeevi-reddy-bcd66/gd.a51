;---------------------------------------------------
; Controlling LEDs connected to 8051 �C
; Even LEDs ON, then Odd LEDs ON
; Delay : 5 seconds using Timer-0
; Clock : 12 MHz
; Tool  : Keil �Vision (A51 Assembler)
;---------------------------------------------------

ORG 0000H                 ; Program start address

MAIN:
    MOV TMOD, #01H        ; Timer-0 Mode-1 (16-bit timer)
    MOV R6, #05H          ; Repeat sequence 5 times

REPEAT:
    MOV P1, #55H          ; 01010101 ? Even LEDs ON
    ACALL DELAY_5S        ; 5-second delay

    MOV P1, #0AAH         ; 10101010 ? Odd LEDs ON
    ACALL DELAY_5S        ; 5-second delay

    DJNZ R6, REPEAT       ; Repeat sequence 5 times

STOP:
    SJMP STOP             ; Halt program execution safely

;---------------------------------------------------
; 5-Second Delay Subroutine using Timer-0
; 12 MHz clock ? 1 machine cycle = 1 �s
; 50 ms delay � 100 = 5 seconds
;---------------------------------------------------

DELAY_5S:
    MOV R5, #100          ; Loop count for 5 seconds

DELAY_LOOP:
    MOV TH0, #3CH         ; Load timer for 50 ms
    MOV TL0, #0B0H
    SETB TR0              ; Start Timer-0

WAIT:
    JNB TF0, WAIT         ; Wait until timer overflows
    CLR TR0               ; Stop Timer-0
    CLR TF0               ; Clear overflow flag
    DJNZ R5, DELAY_LOOP   ; Repeat until 5 seconds
    RET

END