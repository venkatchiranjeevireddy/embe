.\lab8111.o: lab8111.c
