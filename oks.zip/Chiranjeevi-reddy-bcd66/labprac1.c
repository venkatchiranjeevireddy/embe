#include <reg51.h>

void delay(void);

void main(void)
{
    while(1)
    {
        P1 = 0x00;   // turn ON all LEDs (active low)
        delay();

        P1 = 0xFF;   // turn OFF all LEDs
        delay();
    }
}

void delay(void)
{
    unsigned int i, j;

    for(i = 0; i < 255; i++);
    for(j = 0; j < 255; j++);
}