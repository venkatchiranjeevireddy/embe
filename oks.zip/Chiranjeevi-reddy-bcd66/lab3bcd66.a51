ORG 0000H

MOV R4, #00H     ; Clear count
MOV A, R1        ; Load number into A
MOV R2, #08H     ; 8 bits counter

UP:
RRC A            ; Rotate right through carry
JNC SKIP         ; If no carry, skip
INC R4           ; If carry=1, increment count

SKIP:
DJNZ R2, UP       ; Repeat 8 times

END
