#include <reg51.h>

#define lcd P1      // P1 = LCD Data pins

sbit rs = P2^0;     // RS Pin
sbit rw = P2^1;     // RW Pin
sbit e  = P2^2;     // Enable pin

void delay (unsigned int);      // Delay function
void cmd (unsigned char);       // LCD Command Send function
void ldata (unsigned char);     // LCD Data send Function

char msg1[15] = "INTERFACING LCD";   // Write message on LCD
char msg2[15] = "WITH 8051";         // Write message on LCD

void delay (unsigned int d)
{
    unsigned int i;

    for (; d > 0; d--)
    {
        for (i = 250; i > 0; i--);
    }
}
void cmd (unsigned char c)
{
    lcd = c;      // Put c into LCD
    rs = 0;       // RS is equal to 0
 rw = 0;       // RW is equal to 0
    e  = 1;       // EN is equal to 1
    delay(5);     // Delay
    e  = 0;       // EN is equal to 0
}

void ldata (unsigned char c)
{
    lcd = c;      // Put c into LCD
    rs = 1;       // RS is equal to 1
    rw = 0;       // RW is equal to 0
    e  = 1;       // EN is equal to 1
    delay(5);     // Delay
    e  = 0;       // EN is equal to 0
}
// Main Function

void main()
{
    int i;
    cmd(0x38);   // Set function 0011 1000
    cmd(0x0C);   // Display ON cursor OFF
    cmd(0x01);   // Clear display
    cmd(0x80);   // Command to force the cursor to first line

    while(1)
    {
        delay(10);
        cmd(0x80);
        for(i = 0; i < sizeof(msg1); i++)
        {
            ldata(msg1[i]);
        }

        cmd(0xC0);
        for(i = 0; i < sizeof(msg2); i++)
        {
            ldata(msg2[i]);
        }
    }
}