.\lab62.o: lab62.s
