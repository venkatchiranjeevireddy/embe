.\lab81bcd0066.o: lab81bcd0066.s
