.\lab72.o: lab72.c
.\lab72.o: C:\Keil\ARM\Inc\Philips\lpc214x.h
