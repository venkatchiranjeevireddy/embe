        AREA ADD_ODD, CODE, READONLY
        ENTRY

        MOV R0, #1      ; first odd number
        MOV R1, #10     ; counter
        MOV R2, #0      ; sum

LOOP
        ADD R2, R2, R0  ; sum = sum + odd
        ADD R0, R0, #2  ; next odd number
        SUBS R1, R1, #1 ; decrease counter
        BNE LOOP

STOP
        B STOP
        AREA AP_PROG, CODE, READONLY
        ENTRY

        MOV R0, #3      ; first term (a)
        MOV R1, #7      ; common difference (d)
        MOV R2, #10     ; number of terms

LOOP
        ADD R0, R0, R1  ; next term = previous + d
        SUBS R2, R2, #1 ; decrease counter
        BNE LOOP

STOP
        B STOP

        END