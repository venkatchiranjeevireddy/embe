#include <LPC214x.h>
void init(void);
void delay_ms(int);

int main()
{
int i;
unsigned char c[] = "Admission 2023 \n"; // Send data by writing to U0THR

init();

while(1)
{
for(i = 0; i <= 17; i++)
{
U0THR = c[i];
while(!(U0LSR & 0x20)); // Check status of one bit of U0LSR
delay_ms(250);
}
}
}

void init()
{
PINSEL0 = 0x05;
U0LCR = 0x83; // 8-N-1, enable divisors
U0DLL = 0x62; // 9600 baud rate
U0DLM = 0x00;
U0LCR = 0x03; // 8-N-1, disable divisors
}

void delay_ms(int x)
{
int a, b;
for(a = 0; a < x; a++)
{
for(b = 0; b < 3000; b++);
}
}