#include <reg51.h>

void delay_5s(void);

void main()
{
    unsigned char r6 = 5;

    TMOD = 0x01;   // Timer0 Mode1

    while(r6--)
    {
        P1 = 0x55;   // Even LEDs
        delay_5s();

        P1 = 0xAA;   // Odd LEDs
        delay_5s();
    }

    while(1);
}

void delay_5s(void)
{
    unsigned char r5;

    for(r5 = 0; r5 < 100; r5++)
    {
        TR0 = 0;      // ? Stop timer FIRST
        TF0 = 0;      // ? Clear flag BEFORE starting

        TH0 = 0x3C;   // Reload every time
        TL0 = 0xB0;

        TR0 = 1;      // Start timer

        while(TF0 == 0);  // Wait overflow

        TR0 = 0;      // Stop again (safe)
        TF0 = 0;      // Clear again
    }
}