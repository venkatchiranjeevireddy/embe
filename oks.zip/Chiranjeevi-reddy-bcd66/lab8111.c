#include <reg51.h>
unsigned char step[8] = {
0x01, 0x03, 0x02, 0x06,
0x04, 0x0C, 0x08, 0x09
};

void delay(unsigned int ms)
{
unsigned int i,j;
for(i=0;i<msi++){i for(j=0;j<1000;j++);
}}

void main()
{
int i;

while(1)
{
for(i=0;i<8;i++)
{
P1 = step[i];
delay(5);
}
}
}