#include <lpc214x.h>

// Control Pins
#define EN (1<<7)   // P0.7
#define RS (1<<8)   // P0.8
#define RW (1<<9)   // P0.9

void delay()
{
    int i;
    for(i=0;i<50000;i++);
}

// Send Command
void lcd_cmd(unsigned char cmd)
{
    IO1CLR = 0x00FF0000;           // Clear P1.16�P1.23
    IO1SET = (cmd << 16);          // Send command

    IO0CLR = RS;                   // RS = 0
    IO0CLR = RW;                   // RW = 0

    IO0SET = EN;                   // EN = 1
    delay();
    IO0CLR = EN;                   // EN = 0
    delay();
}

// Send Data
void lcd_data(unsigned char data)
{
    IO1CLR = 0x00FF0000;
    IO1SET = (data << 16);         // Send data

    IO0SET = RS;                   // RS = 1
    IO0CLR = RW;                   // RW = 0

    IO0SET = EN;
    delay();
    IO0CLR = EN;
    delay();
}

// LCD Init
void lcd_init()
{
    lcd_cmd(0x38);  // 8-bit, 2 line
    lcd_cmd(0x0C);  // display ON
    lcd_cmd(0x06);  // entry mode
    lcd_cmd(0x01);  // clear
}

// String display
void lcd_string(char *str)
{
    while(*str)
    {
        lcd_data(*str++);
    }
}

int main()
{
    // GPIO configuration
    PINSEL0 = 0x00000000;
    PINSEL1 = 0x00000000;

    // P1.16�P1.23 as output (data)
    IO1DIR |= 0x00FF0000;

    // P0.7, P0.8, P0.9 as output (control)
    IO0DIR |= (1<<7) | (1<<8) | (1<<9);

    delay();   // initial delay

    lcd_init();

    lcd_string("My India");

    while(1);
}