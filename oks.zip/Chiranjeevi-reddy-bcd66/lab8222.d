.\lab8222.o: lab8222.c
.\lab8222.o: C:\Keil\ARM\Inc\Philips\LPC214x.h
