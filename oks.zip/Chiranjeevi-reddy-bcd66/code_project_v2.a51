ORG 0000H
LJMP START

ORG 000BH        ; Timer0 interrupt vector
LJMP TIMER0_ISR

ORG 0100H

ARR: DB 0C0H,0F9H,0A4H,0B0H,099H,092H,082H,0F8H,080H,090H

; Time digits
SEC_L EQU 30H
SEC_H EQU 31H
MIN_L EQU 32H
MIN_H EQU 33H
HR_L  EQU 34H
HR_H  EQU 35H
TICK  EQU 36H

START:
    MOV SEC_L,#00
    MOV SEC_H,#00
    MOV MIN_L,#00
    MOV MIN_H,#00
    MOV HR_L,#00
    MOV HR_H,#00
    MOV TICK,#00

; Timer0 Mode 1 (16-bit)
    MOV TMOD,#01H
    MOV TH0,#3CH     ; ~50ms delay
    MOV TL0,#0B0H

    SETB ET0         ; enable Timer0 interrupt
    SETB EA          ; global interrupt
    SETB TR0         ; start timer

MAIN:
    ACALL DISPLAY
    SJMP MAIN

; -------- TIMER INTERRUPT --------
TIMER0_ISR:
    MOV TH0,#3CH
    MOV TL0,#0B0H

    INC TICK
    MOV A,TICK
    CJNE A,#20,EXIT_ISR   ; 20 � 50ms = 1 sec

    MOV TICK,#00

; -------- SECONDS --------
    INC SEC_L
    MOV A,SEC_L
    CJNE A,#10,EXIT_ISR
    MOV SEC_L,#00
    INC SEC_H

    MOV A,SEC_H
    CJNE A,#6,EXIT_ISR
    MOV SEC_H,#00

; -------- MINUTES --------
    INC MIN_L
    MOV A,MIN_L
    CJNE A,#10,EXIT_ISR
    MOV MIN_L,#00
    INC MIN_H

    MOV A,MIN_H
    CJNE A,#6,EXIT_ISR
    MOV MIN_H,#00

; -------- HOURS (24 format) --------
    INC HR_L

    MOV A,HR_H
    CJNE A,#2,CHK_HR10

    MOV A,HR_L
    CJNE A,#4,EXIT_ISR
    MOV HR_L,#00
    MOV HR_H,#00
    SJMP EXIT_ISR

CHK_HR10:
    MOV A,HR_L
    CJNE A,#10,EXIT_ISR
    MOV HR_L,#00
    INC HR_H

EXIT_ISR:
    RETI

; -------- DISPLAY FUNCTION --------
DISPLAY:

; ---- SEC_L ----
    MOV P2,#0FFH
    SETB P1.5
    CLR P1.0
    CLR P1.1
    CLR P1.2
    CLR P1.3
    CLR P1.4

    MOV A,SEC_L
    ACALL SEG
    ACALL DELAY

; ---- SEC_H ----
    MOV P2,#0FFH
    SETB P1.4
    CLR P1.0
    CLR P1.1
    CLR P1.2
    CLR P1.3
    CLR P1.5

    MOV A,SEC_H
    ACALL SEG
    ACALL DELAY

; ---- MIN_L (DP ON) ----
    MOV P2,#0FFH
    SETB P1.3
    CLR P1.0
    CLR P1.1
    CLR P1.2
    CLR P1.4
    CLR P1.5

    MOV A,MIN_L
    ACALL SEG_DP
    ACALL DELAY

; ---- MIN_H ----
    MOV P2,#0FFH
    SETB P1.2
    CLR P1.0
    CLR P1.1
    CLR P1.3
    CLR P1.4
    CLR P1.5

    MOV A,MIN_H
    ACALL SEG
    ACALL DELAY

; ---- HR_L (DP ON) ----
    MOV P2,#0FFH
    SETB P1.1
    CLR P1.0
    CLR P1.2
    CLR P1.3
    CLR P1.4
    CLR P1.5

    MOV A,HR_L
    ACALL SEG_DP
    ACALL DELAY

; ---- HR_H ----
    MOV P2,#0FFH
    SETB P1.0
    CLR P1.1
    CLR P1.2
    CLR P1.3
    CLR P1.4
    CLR P1.5

    MOV A,HR_H
    ACALL SEG
    ACALL DELAY

    RET

; -------- SEGMENT DISPLAY --------
SEG:
    MOV DPTR,#ARR
    MOVC A,@A+DPTR
    ORL A,#80H
    MOV P2,A
    RET

SEG_DP:
    MOV DPTR,#ARR
    MOVC A,@A+DPTR
    ANL A,#7FH
    MOV P2,A
    RET

; -------- SMALL DELAY (for multiplexing only) --------
DELAY:
    MOV R6,#02
D1: MOV R7,#100
D2: DJNZ R7,D2
    DJNZ R6,D1
    RET

END
