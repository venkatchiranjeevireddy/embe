#include <lpc214x.h>

#define LED1 (1<<0)  // P0.0
#define LED2 (1<<1)  // P0.1
#define LED3 (1<<2)  // P0.2
#define SW   (1<<3)  // P0.3

volatile unsigned int state = 0;

void Delay(void)
{
    volatile int i,j;
    for(i=0;i<3000;i++)
        for(j=0;j<500;j++);
}

int main(void)
{
    PINSEL0 = 0x00000000; // GPIO mode
    IO0DIR |= (LED1 | LED2 | LED3); // LEDs output
    IO0DIR &= ~SW;                  // Switch input

    while(1)
    {
        if((IO0PIN & SW) == 0)  // Switch pressed
        {
            state = (state + 1) % 3;
            while((IO0PIN & SW) == 0); // wait for release
            Delay();                   // debounce
        }

        IO0CLR = LED1 | LED2 | LED3;  // Clear LEDs

        if(state == 0)
        {
            IO0SET = LED1;
            Delay(); IO0CLR = LED1; Delay();
        }
        else if(state == 1)
        {
            IO0SET = LED1 | LED2;
            Delay(); IO0CLR = LED1 | LED2; Delay();
        }
        else if(state == 2)
        {
            IO0SET = LED1 | LED2 | LED3;
            Delay(); IO0CLR = LED1 | LED2 | LED3; Delay();
        }
    }
}








