#include <reg51.h>
sbit SW = P3^2;
sbit IND = P1^0;
void Delay()
{
 int i = 0, j = 0;
 for(i = 0; i < 100; i++)
 {
 for(j = 0; j < 1000; j++);
 }
}
void extint0() interrupt 0
{
 IND = 1;
 Delay();
 IND = 0;
 Delay();
}
void main()
{
 IE = 0x81;
 while(1)
 {
 P2 = 0x55;
 Delay();
 P2 = 0xAA;
 Delay();
 }
}