        AREA RESET, CODE, READONLY
        ENTRY
        ARM

IO0DIR  EQU 0xE0028008
IO0SET  EQU 0xE0028004
IO0CLR  EQU 0xE002800C

__main

; Configure P0.10 as output
        LDR     R0, =IO0DIR
        LDR     R1, [R0]
        ORR     R1, R1, #(1<<10)
        STR     R1, [R0]

MAIN

; LED ON
        LDR     R0, =IO0SET
        MOV     R1, #(1<<10)
        STR     R1, [R0]
        BL      DELAY

; LED OFF
        LDR     R0, =IO0CLR
        MOV     R1, #(1<<10)
        STR     R1, [R0]
        BL      DELAY

        B       MAIN

DELAY
        LDR     R2, =50000

LOOP
        SUBS    R2, R2, #1
        BNE     LOOP
        BX      LR

        END