#include <lpc214x.h>

// Control Pins (Port 0)
#define RS (1<<8)    // P0.8
#define RW (1<<9)    // P0.9
#define EN (1<<10)   // P0.10

void delay()
{
    int i,j;
    for(i=0;i<500;i++)
        for(j=0;j<2000;j++);
}

// Send Command
void lcd_cmd(unsigned char cmd)
{
    IO0CLR = 0x000007FF;           // Clear P0.0�P0.10
    IO0SET = (cmd & 0xFF);         // Send command to P0.0�P0.7

    IO0CLR = RS;                   // RS = 0 (command)
    IO0CLR = RW;                   // RW = 0 (write)

    IO0SET = EN;                   // EN = 1
    delay();
    IO0CLR = EN;                   // EN = 0
}

// Send Data
void lcd_data(unsigned char data)
{
    IO0CLR = 0x000007FF;
    IO0SET = (data & 0xFF);        // Send data

    IO0SET = RS;                   // RS = 1 (data)
    IO0CLR = RW;                   // RW = 0

    IO0SET = EN;
    delay();
    IO0CLR = EN;
}

// LCD Initialization
void lcd_init()
{
    lcd_cmd(0x38);  // 8-bit mode, 2 line
    lcd_cmd(0x0C);  // Display ON, cursor OFF
    lcd_cmd(0x01);  // Clear display
    lcd_cmd(0x06);  // Entry mode
}

// Display String
void lcd_string(char *str)
{
    while(*str)
    {
        lcd_data(*str++);
    }
}

int main()
{
    // Make all Port 0 pins GPIO
    PINSEL0 = 0x00000000;
    PINSEL1 = 0x00000000;

    // Set P0.0 to P0.10 as output
    IO0DIR = 0x000007FF;

    // Initial delay for LCD
    delay();
    delay();

    lcd_init();

    lcd_string("2023 Batch");

    while(1);
}