.\lab81code.o: lab81code.c
.\lab81code.o: C:\Keil\ARM\Inc\Philips\lpc214x.h
