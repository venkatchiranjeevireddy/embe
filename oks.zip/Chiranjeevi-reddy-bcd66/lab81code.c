#include <lpc214x.h>

// Function for delay
void delay(unsigned int count)
{
    unsigned int i, j;
    for(i = 0; i < count; i++)
        for(j = 0; j < 1000; j++);
}

// Hex values for digits 0-9 (Common Cathode)
unsigned char seg_code[] = {0xFC, 0x60, 0xDA, 0xF2, 0x66, 0xB6, 0xBE, 0xE0, 0xFE, 0xF6};

int main()
{
    unsigned int i;

    IO0DIR = 0x000000FF; // Set P0.0-P0.7 as output

    while(1)
    {
        for(i = 0; i < 10; i++)
        {
            IO0PIN = seg_code[i]; // Send digit code to port
            delay(1000);
        }
    }
}