#include <reg51.h>
sbit OUT  = P2^5;  
sbit INP  = P1^7;   
sbit COPY = P1^0;   
void timer0_ISR(void) interrupt 1
{
    OUT = !OUT;   
}
void main()
{ 
    OUT = 0;        
    TMOD = 0x02;    
    TH0  = 0xD2;    
    TL0  = 0xD2;    
    EA  = 1;        
    ET0 = 1;        
    TR0 = 1;        
    while(1)
    {
        COPY = INP;   
    }
}