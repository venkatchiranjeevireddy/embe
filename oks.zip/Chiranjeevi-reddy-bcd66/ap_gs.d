.\ap_gs.o: ap_gs.s
