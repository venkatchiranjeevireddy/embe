.\lab731.o: lab731.c
.\lab731.o: C:\Keil\ARM\Inc\Philips\lpc214x.h
