#include <lpc214x.h>

void delay_5s(void);

int main(void)
{
    int i, j;

    IO0DIR = 0x000000FF;   // Make P0.0�P0.7 as output (LEDs)

    for(i = 0; i < 5; i++)
    {
        IO0SET = 0x00000055;   // Even LEDs ON
        IO0CLR = 0x000000AA;   // Ensure others OFF
        delay_5s();

        IO0SET = 0x000000AA;   // Odd LEDs ON
        IO0CLR = 0x00000055;
        delay_5s();
    }

    while(1);
}

//--------------------------------------
// Rough 5-second delay (software loop)
//--------------------------------------
void delay_5s(void)
{
    int i, j;

    for(i = 0; i < 5000; i++)
    {
        for(j = 0; j < 600; j++);
    }
}