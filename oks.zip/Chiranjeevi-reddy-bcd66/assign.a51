ORG 0000H

MOV R0, #30H      ; Start of array
MOV R2, #05H      ; Number of elements

MOV A, @R0        ; Load first element
MOV 41H, A        ; Assume first element is largest

INC R0

NEXT:
MOV A, @R0
CJNE A, 41H, CHECK
SJMP SKIP

CHECK:
JC SKIP           ; If A < largest, skip
MOV 41H, A        ; Update largest

SKIP:
INC R0
DJNZ R2, NEXT

MOV A, 41H
MOV 40H, A        ; Store largest at 40H

END
