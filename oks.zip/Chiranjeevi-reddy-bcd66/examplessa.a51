ORG 0000H

MOV R7,#05H          ; N = 5 bytes

MOV DPTR,#3000H      ; First block address

MOV R5,#05H          ; Counter for second block
MOV R6,#00H          ; Offset

LOOP:
; Read from 3000H + offset
MOV DPTR,#3000H
MOV A,R6
ADD A,DPL
MOV DPL,A
MOVX A,@DPTR
MOV R1,A             ; Store first value

; Read from 3050H + offset
MOV DPTR,#3050H
MOV A,R6
ADD A,DPL
MOV DPL,A
MOVX A,@DPTR
MOV R2,A             ; Store second value

; Write second to first
MOV DPTR,#3000H
MOV A,R6
ADD A,DPL
MOV DPL,A
MOV A,R2
MOVX @DPTR,A

; Write first to second
MOV DPTR,#3050H
MOV A,R6
ADD A,DPL
MOV DPL,A
MOV A,R1
MOVX @DPTR,A

INC R6               ; Next offset
DJNZ R7,LOOP

HERE: SJMP HERE

END