#include <reg51.h>
#define LCD P2

sbit RS = P3^0;
sbit RW = P3^1;
sbit EN = P3^2;
sbit LED = P1^0;

unsigned char count = 0;

void delay()
{
unsigned char i,j;
for(i=0;i<255;i++)
for(j=0;j<255;j++);
}

void lcd_cmd(unsigned char cmd)
{
LCD = cmd;
RS=0; RW=0;
EN=1; delay(); EN=0;
}

void lcd_data(unsigned char dat)
{
LCD = dat;
RS=1; RW=0;
EN=1; delay(); EN=0;
}

void lcd_init()
{
lcd_cmd(0x38);
lcd_cmd(0x0C);
lcd_cmd(0x01);
lcd_cmd(0x06);
}

// TIMER ISR
void timer0_ISR(void) interrupt 1
{
TR0 = 0;

TH0 = 0x3C;
TL0 = 0xB0;

count++;
LED = ~LED;

lcd_cmd(0x01);
lcd_data(count + 0x30);

if(count == 5)
{
ET0 = 0;
TR0 = 0;
}
else
{
TR0 = 1;
}
}

void main()
{
lcd_init();

TMOD = 0x01;
TH0 = 0x3C;
TL0 = 0xB0;

ET0 = 1;
EA = 1;
TR0 = 1;

while(1);
}