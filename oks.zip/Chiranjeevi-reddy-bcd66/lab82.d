.\lab82.o: lab82.c
.\lab82.o: C:\Keil\ARM\Inc\Philips\lpc214x.h
