#include <LPC214x.h>

unsigned char step_sequence[4] = {0x03, 0x06, 0x0C, 0x09};

void delay(void)
{
    unsigned int i;
    for(i = 0; i < 80000; i++);
}

int main()
{
    int i;

    IO0DIR |= 0x0F;

    while(1)
    {
        for(i = 0; i < 4; i++)
        {
            IO0CLR = 0x0F;
            IO0SET = step_sequence[i];
            delay();
        }
    }
}