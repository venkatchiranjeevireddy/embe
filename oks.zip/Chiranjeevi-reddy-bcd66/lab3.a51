ORG 0000H          ; Program start address

MAIN:
    MOV P2, #00H   ; Configure Port 2 as output (LCD data bus)

    CLR P3.0       ; RS = 0
    CLR P3.1       ; RW = 0
    CLR P3.2       ; EN = 0

    ACALL LCD_INIT     ; Initialize LCD
    ACALL LCD_STRING   ; Display required string

HERE:
    SJMP HERE      ; Stay here after display
; LCD Initialization Routine

LCD_INIT:
    MOV A, #38H        ; 8-bit mode, 2 lines, 5x7 font
    ACALL LCD_CMD

    MOV A, #0CH        ; Display ON, cursor OFF
    ACALL LCD_CMD

    MOV A, #01H        ; Clear display
    ACALL LCD_CMD

    MOV A, #06H        ; Entry mode: increment cursor
    ACALL LCD_CMD

    RET
; Send Command to LCD

LCD_CMD:
    MOV P2, A        ; Command on data lines

    CLR P3.0         ; RS = 0 (command)
    CLR P3.1         ; RW = 0 (write)

    SETB P3.2        ; EN = 1
    ACALL DELAY

    CLR P3.2         ; EN = 0 (latch command)
    ACALL DELAY

    RET
; Send Data (Character) to LCD

LCD_DATA:
    MOV P2, A        ; Data on data lines

    SETB P3.0        ; RS = 1 (data)
    CLR  P3.1        ; RW = 0 (write)

    SETB P3.2        ; EN = 1
    ACALL DELAY

    CLR  P3.2        ; EN = 0 (latch data)
    ACALL DELAY

    RET
; Display String "2023 Batch 2"

LCD_STRING:
    MOV A, #'2'
    ACALL LCD_DATA

    MOV A, #'0'
    ACALL LCD_DATA

    MOV A, #'2'
    ACALL LCD_DATA

    MOV A, #'3'
    ACALL LCD_DATA

    MOV A, #' '
    ACALL LCD_DATA

    MOV A, #'B'
    ACALL LCD_DATA

    MOV A, #'a'
    ACALL LCD_DATA

    MOV A, #'t'
    ACALL LCD_DATA

    MOV A, #'c'
    ACALL LCD_DATA

    MOV A, #'h'
    ACALL LCD_DATA

    MOV A, #' '
    ACALL LCD_DATA

    MOV A, #'3'
    ACALL LCD_DATA

    RET
; Software Delay Routine

DELAY:
    MOV R7, #255

D1:
    MOV R6, #255

D2:
    DJNZ R6, D2
    DJNZ R7, D1

    RET
END

