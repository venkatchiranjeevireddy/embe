ASM:

ORG 0000H
LJMP MAIN

ORG 000BH            ; Timer-0 Interrupt Vector
LJMP T0_ISR

; MAIN PROGRAM

ORG 0030H

MAIN:
    MOV P2,#00H          ; LCD data port output
    CLR P3.0             ; RS = 0
    CLR P3.1             ; RW = 0
    CLR P3.2             ; EN = 0

    ACALL LCD_INIT

    MOV TMOD,#01H        ; Timer-0 Mode-1
    MOV TH0,#3CH
    MOV TL0,#0B0H

    MOV R5,#00H          ; Iteration counter = 0

    SETB ET0             ; Enable Timer-0 interrupt
    SETB EA              ; Enable global interrupt
    SETB TR0             ; Start Timer-0

HERE:
    SJMP HERE            ; Main idle loop
	; TIMER-0 ISR

T0_ISR:
    CLR TR0              ; Stop timer

    MOV TH0,#3CH         ; Reload timer
    MOV TL0,#0B0H

    INC R5               ; Increment iteration count
    CPL P1.0             ; Toggle LED

    MOV A,#01H           ; Clear LCD
    ACALL LCD_CMD
    MOV A,#30H           ; ASCII '0'
    ADD A,R5             ; Convert count to ASCII
    ACALL LCD_DATA

    CJNE R5,#05,RESTART  ; If count ? 5, continue

    CLR ET0              ; Disable Timer interrupt
    CLR TR0              ; Stop Timer permanently
    RETI

RESTART:
    SETB TR0             ; Restart timer
    RETI


; LCD INITIALIZATION

LCD_INIT:
    MOV A,#38H
    ACALL LCD_CMD
    MOV A,#0CH
    ACALL LCD_CMD
    MOV A,#01H
    ACALL LCD_CMD
    MOV A,#06H
    ACALL LCD_CMD
    RET
	; LCD COMMAND ROUTINE

LCD_CMD:
    MOV P2,A
    CLR P3.0
    CLR P3.1
    SETB P3.2
    ACALL DELAY
    CLR P3.2
    ACALL DELAY
    RET


; LCD DATA ROUTINE

LCD_DATA:
    MOV P2,A
    SETB P3.0
    CLR P3.1
    SETB P3.2
    ACALL DELAY
	    CLR P3.2
    ACALL DELAY
    RET


; SOFTWARE DELAY

DELAY:
    MOV R7,#255
D1:
    MOV R6,#255
D2:
    DJNZ R6,D2
    DJNZ R7,D1
    RET

END